/** Automatically generated file. DO NOT MODIFY */
package org.example.androidsdk.demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}